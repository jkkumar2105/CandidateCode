﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;

namespace WebApplication1.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            IEnumerable<string> brands= new List<string>();
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:49713/api/");
                //HTTP GET
                var responseTask = client.GetAsync("CarWale");
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    brands = result.Content.ReadAsAsync<IEnumerable<string>>().Result;
                }
            }

            return View(brands);
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}
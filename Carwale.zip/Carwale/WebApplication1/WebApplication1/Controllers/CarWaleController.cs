﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace WebApplication1.Controllers
{
    [Route("api/CarWale")]
    public class CarWaleController : ApiController
    {
        // GET: api/CarWale
        [HttpGet]
        public IEnumerable<string> Get()
        {

            var mappedPath = System.Web.Hosting.HostingEnvironment.MapPath(@"~/Content\Data\Brands.json");
            string allText = System.IO.File.ReadAllText(mappedPath);

            IEnumerable<string> BrandData = JsonConvert.DeserializeObject<IEnumerable<string>>(allText);
            
            return BrandData;
        }

        // GET: api/CarWale/5
        public string Get(int id)
        {
            return "value";
        }

        // POST: api/CarWale
        public void Post([FromBody]string value)
        {
        }

        // PUT: api/CarWale/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE: api/CarWale/5
        public void Delete(int id)
        {
        }
    }
}
